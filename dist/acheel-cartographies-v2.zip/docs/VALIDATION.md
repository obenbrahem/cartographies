# Validation de livraison — 5 novembre 2026

- 35 contrôles de données réussis : égalité des JSON extraits aux blocs originaux, empreintes et octets des pièces jointes, 102 processus, 7 produits, 105 offres, 19 formules Santé, 242 flux partenaires, identifiants uniques, relations sans cible manquante et séparation produit/offre.
- 53 contrôles navigateur réussis sous Chromium : recherche, parcours croisés, comparateur, quatre gammes Santé, filtres et résultats vides, matrice, chronologie, graphe, preuves, zoom, exports SVG/CSV/JSON, persistance du suivi local, navigation mobile, réduction du mouvement et absence d’erreur JavaScript.
- Les 903 objets du référentiel ont chacun été ouverts en fiche et leur titre contrôlé.
- Les vues Fonctionnement, Santé, Offres, Interactions, Validations, Sources et Outils ne débordent pas horizontalement à 390 px.
- Le contenu complet du HTML autonome a été exécuté dans un navigateur hors ligne : accueil et graphe fonctionnels, aucune requête externe. La navigation `file://` est bloquée par la politique du navigateur cloud ; le test utilise le contenu autonome chargé en mémoire, sans désactiver cette politique. L’ouverture directe sur un poste utilisateur reste à valider dans son navigateur.
- Les trois fichiers sources restent inchangés ; tous les fichiers applicatifs du dépôt étaient nouveaux, le dépôt initial étant sans commit.

Les tests vérifient la migration et le fonctionnement de l’outil, pas l’exactitude opérationnelle des informations métier. Les 87 relations proposées restent à confirmer. Les textes intégraux des conventions et la quatrième cartographie Outils ne sont pas disponibles.

Commandes : `python3 scripts/build.py`, `python3 tests/validate_data.py`, `node --check app.js`, `node tests/smoke.cjs`, `node tests/mobile_capture.cjs`. Les tests navigateur utilisent Playwright fourni par l’environnement et Chromium système ; ils ne sont pas requis à l’exécution du portail.

## Extension Audit & contrôle

19 contrôles navigateur complémentaires réussis : accès aux P1, exactitude du compteur, documentation minimale avant conclusion achevée, préparation partielle, persistance des preuves, distinction suivi/conclusion, échappement des notes, filtres de conclusion et résultats vides, export complet avec neutralisation des formules de tableur, navigation au partenaire exact, formulaire mobile et accès hors ligne. Les exemples de test sont limités au navigateur temporaire ; ils ne sont pas injectés dans les données livrées. Les captures et rapports de test ne font pas partie du ZIP de déploiement.

Commande complémentaire : `node tests/audit_workflow.cjs`. Les 53 contrôles antérieurs ont été rejoués après l’extension.
