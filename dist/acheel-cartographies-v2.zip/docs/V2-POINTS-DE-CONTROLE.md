# V2 — Identifier les points de contrôle

Cette deuxième version est conçue pour l’équipe Audit qui a construit la plateforme. Elle permet de distinguer les points à examiner dans le fonctionnement d’Acheel, sans les confondre avec des anomalies ou des conclusions de test.

## Lecture centrale

**Activité / processus → risques cités → point de contrôle → responsable à confirmer → preuve attendue.**

L’accueil privilégie « Identifier les points de contrôle ». La navigation « Points de contrôle » propose recherche et filtres par chaîne, entité, fonction, processus, origine et suivi de qualification. Les produits, partenaires et outils à venir restent accessibles. Les anciens registres et feuilles de travail sont conservés dans « Validations & travaux ».

## Origine et limites

Les mentions sont extraites des rubriques « Contrôles qui devraient être mis en place » et « Contrôles à mener » des fiches fonctionnelles. Trois classes aident à lire les sources : éléments de maîtrise déclarés / non testés ; propositions ; questions à confirmer. Le classement repose sur le libellé et la rubrique, et demande une validation métier.

Une entrée peut regrouper plusieurs contrôles. Le compteur porte sur les **mentions / questions extraites**, pas sur un nombre de contrôles indépendants ou opérationnels certifiés. Les introductions et éléments de contexte, notamment la couverture du plan 2026, restent consultables avec leurs chemins source. Les fiches sans mention extraite apparaissent dans « Processus à documenter ». Cela ne prouve aucune absence de contrôle.

Les risques sont cités au **niveau du processus**. Aucun lien individuel risque ↔ contrôle n’est inventé. Le responsable de la fonction ou le pilote du processus n’est pas automatiquement attribué au point. Le responsable du contrôle et les preuves attendues restent non renseignés tant que l’équipe ne les a pas qualifiés. L’aide à la préparation des preuves est une suggestion, pas une preuve reçue.

## Qualifier un point

Ouvrir « Examiner le point ». Consulter le processus, les risques, les acteurs, outils et le contexte. Renseigner facultativement le risque rattaché, le responsable à confirmer, les preuves attendues, la périodicité et les notes, puis choisir « À qualifier », « Retenu pour revue » ou « Hors périmètre actuel ». Ces annotations ne constituent ni un résultat de contrôle ni une modification des données sources.

Les qualifications sont locales à ce navigateur, séparées des suivis V1. Les exports CSV portent sur le périmètre filtré et indiquent la provenance de chaque point. L’export JSON conserve les annotations pour les transférer ; l’import vérifie l’empreinte du fichier fonctionnel et accepte uniquement des identifiants de la V2 et préserve toute annotation locale existante en cas de doublon. Archiver et sécuriser les exports avec les règles internes Acheel.

## Fichiers et démarrage

- HTML autonome : `dist/acheel-cartographies-v2-points-controle.html`.
- ZIP de déploiement V2 : `dist/acheel-cartographies-v2.zip` ; ouvrir `index.html` à sa racine sur l’hébergement privé.
- Code V2 dans le dépôt : `v2/index.html`, `v2/app.js` généré, `v2/controls-ui.js` et `v2/styles.css`.
- Extraction traçable : `v2/data/controles.json`.
- Regénérer : `python3 scripts/build_v2.py` ; ne pas modifier le `v2/app.js` généré. Les modifications spécifiques se font dans `v2/controls-ui.js`, `v2/styles.css` et les intégrations de `scripts/build_v2.py`.
- Depuis le serveur statique du dépôt, la V2 est accessible sous `/v2/`. Aucun service ou secret supplémentaire n’est requis. Ne pas créer de worktree pour une simple remise en route.

La V1 livrée, ses sources, son code et ses archives restent inchangés ; les empreintes sont vérifiées à chaque construction V2. L’authentification et l’autorisation de l’hébergement privé restent à assurer côté serveur/SSO. La quatrième cartographie « Outils ACHEEL » reste signalée à venir.

## Validation de la V2

33 contrôles de données et de packaging ont vérifié notamment les 491 extraits exacts, leurs chemins source, les 102 processus, l’absence de responsables/preuves/liens risque-contrôle inventés, les fichiers autonomes et la préservation de la V1. Les tests navigateur couvrent recherche, pagination, filtres, qualifications locales, exports/imports, parcours entre fiches, produits et offres conservés, mobile et mode hors ligne.

Commandes : `python3 tests/validate_v2.py` et `node tests/v2_smoke.cjs`. Le second utilise Chromium et Playwright fournis par l’environnement. Les exemples de qualification des tests sont limités à des contextes navigateur temporaires, sans modification des données livrées.

Pour conserver exactement la V1 livrée, régénérer uniquement la V2 avec `scripts/build_v2.py`. Le script V1 `scripts/build.py` reconstruit la V1 et peut changer ses sorties ; ne pas le confondre avec la construction de cette deuxième version.
