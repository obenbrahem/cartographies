# Revue critique des cartographies — 5 novembre 2026

Périmètre : trois HTML fournis, sans entretiens métier ni PDF contractuels originaux. Aucune affirmation des sources n’est certifiée indépendamment. « Déclaré dans une source » signifie traçable au HTML, pas confirmé opérationnellement.

## Inventaire et conservation

- Fonctionnement : 14 fonctions, **102 processus**, 6 chaînes, 3 entités, 4 canaux, 4 jeux de flux, 11 mentions d’outils, 16 validations préexistantes. Référence du document : 03/11/2026, V2.0, document de travail.
- Produits : 7 fiches, toutes leurs sections, 16 acteurs, 10 parcours, comparateur, 19 formules Santé, exemples, assistance, glossaire et relations sources.
- Partenaires : 36 partenaires, 105 offres (95 hors statut « annonce », 10 annoncées), 34 analyses de partenaires dans DC, 145 sections conventionnelles, 34 ensembles de flux, 242 flux. Les 2 partenaires sans analyse ne sont pas complétés artificiellement.
- Les trois fichiers dans `sources/` restent identiques aux pièces reçues (empreintes SHA-256 dans le référentiel). Les JSON extraits conservent chaque champ et chaque valeur des blocs de données, y compris les informations non mises en avant dans les cartes de synthèse. Un explorateur de données typées permet d’accéder à l’intégralité du référentiel source.

## Incohérences et limites

1. **Nombre de fiches fonctionnelles** : META.method annonce 86 fiches ; F contient 102 fiches. Divergence conservée, aucune suppression pour faire coïncider les chiffres.
2. **Offre ≠ produit** : une offre partenaire MRH n’est pas assimilée à la fiche Habitation. Pas de clé documentaire commune établie. Plusieurs annonces possèdent déjà un code : 101 codes renseignés ne signifient pas 101 offres Deemeter.
3. **Statuts composites** : actif, config, verif, inactif, nonlance et annonce sont conservés tels quels. La fraîcheur des bordereaux est distincte du statut commercial et contractuel. Aucun statut ne se recalcule à partir d’une absence de bordereau.
4. **Temporalité** : dates de lancement, de fin et de dernier bordereau affichées séparément. La date d’import n’est pas la date d’effet des documents. Date de référence des autres sources non établie globalement.
5. **Indépendance** : GOUV et PLAN décrivent des cumuls opérationnel/contrôle et audit/contrôle permanent. Ces fonctions restent distinctes et les cumuls sont signalés pour validation, jamais régularisés silencieusement.
6. **Conventions** : les analyses DC, les flux DF et les paramètres DPR sont disponibles ; les PDF originaux ne sont pas joints. Le code prévoit ftdata, absent du fichier reçu. Aucune transcription intégrale inventée.
7. **Fiches produits externes** : les liens claude.ai sont conservés dans les données originales, mais ne conditionnent plus l’accès aux informations embarquées.
8. **Noms et identités** : pas de fusion automatique de sociétés/marques homonymes. Seules les trois équivalences explicites Acheel SA / Acheel France / A.C.S. relient acteurs et entités, comme déclaration documentaire.
9. **Outils** : les 11 mentions APPS ne constituent pas la quatrième cartographie. Les outils, affectations et responsabilités cités comme « à confirmer » restent provisoires.
10. **Contradictions internes** : sections attention, constats DF, paramètres et analyses sont conservés avec source et chemin JSON. Une contradiction n’est pas arbitrée automatiquement. Les 185 entrées du registre regroupent validations préexistantes, points d’attention produits, constats partenaires et anomalies de migration ; ce ne sont pas 185 anomalies indépendantes prouvées.

## Direction graphique actualisée

À la demande de l’utilisateur, la palette suit la capture de son interface Acheel : navigation bleu nuit presque noire, fond gris très clair, cartes blanches, titres marine, accents et filets bleu vif. La police Montserrat et le logo source sont embarqués. Les couleurs de validation restent sémantiques.

## Améliorations livrées

Navigation centrale et fil d’Ariane ; recherche multi-référentiels dans tous les champs ; filtres ; fiches dans un panneau latéral ; graphe centré sur un seul objet ; zoom/recentrage ; provenance des relations ; séparation des produits/offres ; matrices, chronologies et bordereaux ; comparateur et explorateur Santé ; parcours pas à pas ; exports JSON/CSV/SVG ; registre local de suivi ; emplacement Outils à venir.

Les rapprochements entre délégations partenaires et fonctions sont des **propositions à confirmer**, générées à partir des intitulés de délégation, affichées en pointillé et accompagnées de leur extrait source. Ils ne constituent pas des liens métier validés. Ils sont exclus des relations déclarées quand le filtre « déclarées seules » est actif.

## Validation requise

Validation du périmètre juridique, des rattachements, des délégations effectives et des correspondances produit/offre par Juridique, Actuariat/Produit, Finance et Opérations. Vérifier les documents signés, versions, dates d’effet et avenants ; rapprocher un export Deemeter daté ; désigner les responsables des objets. Fournir ultérieurement la cartographie Outils. Le registre exportable détaille ces points sans présenter une validation locale comme une certification.

## Orientation audit et contrôle

L’accueil donne accès aux priorités de revue et aux sources. Le registre est prolongé par des feuilles de travail locales : objectif, périmètre, méthode, références des preuves, résultats, conclusion, action, responsable et échéance. Une conclusion saisie par l’utilisateur reste distincte des constats des fichiers sources et du statut de suivi. Aucun niveau de risque, résultat de contrôle ou jugement de conformité n’est calculé automatiquement. Cette version ne stocke pas les pièces et ne propose pas de workflow multi-utilisateur de revue ou d’approbation.
