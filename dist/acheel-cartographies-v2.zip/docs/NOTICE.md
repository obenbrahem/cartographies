# Utilisation et maintenance

## Démarrer

Depuis `/workspace/cartographies`, lancer `python3 -m http.server 8000 --bind 127.0.0.1`. Le site n’utilise ni API ni base de données et ne nécessite aucune clé. Ouvrir `index.html` via un serveur privé approprié. Le fichier `dist/acheel-cartographies-autonome.html` s’ouvre aussi directement, hors ligne, avec ses données, police, logo et originaux embarqués.

## Explorer

- Accueil : trois univers disponibles, quatrième univers Outils explicitement à venir.
- Fonctionnement : chaîne, fonction, puis processus ; la fiche s’ouvre à droite. L’audit et le contrôle permanent restent séparés.
- Produits : fiches détaillées, comparaison de deux produits, parcours transverses, garanties Santé et acteurs.
- Partenaires : filtre par famille et statut source, offres, matrice, chronologie, bordereaux, analyses de conventions, délégations, commissions, échéances et flux.
- Ctrl/Cmd K : rechercher dans tous les champs. Choisir un type pour réduire les résultats.
- Interactions : choisir un type et un objet, ouvrir une fiche en cliquant sur un nœud. Zoom +/−, déplacement par glissement dans le fond et recentrage. La vue limite initialement les relations à huit ; choisir « Toutes » pour voir chaque relation. Le panneau « Preuves » indique les sources exactes. Retirer les rapprochements proposés avec la case dédiée.
- Fiches : le bouton de retour revient à la fiche précédente ; Échap ferme le panneau. Les données complètes et la provenance sont accessibles en fin de fiche.
- Validations : suivi local ouvert / en cours / revu localement. Ce suivi n’est pas une validation documentaire et ne modifie jamais les relations. Exporter le registre CSV pour transmettre le travail ; il n’y a pas de synchronisation multi-utilisateur.
- Sources : originaux, empreintes, audit, architecture et explorateur de tous les champs. Chaque JSON source peut être exporté sans changement.

Les fiches exportent JSON, le graphe exporte SVG et le registre exporte CSV. Le référentiel complet est exportable depuis Sources. L’impression du navigateur peut produire un PDF des vues principales. Les originaux conservent leurs comportements et leurs éventuelles dépendances historiques ; le nouveau portail fonctionne sans appel réseau externe.

## Mettre à jour

1. Archiver les anciens fichiers et le ZIP en environnement privé ; conserver les empreintes et la version.
2. Remplacer uniquement les fichiers originaux concernés dans `sources/` avec des sources métier autorisées. Ne pas modifier silencieusement une contradiction.
3. Revoir les règles dans `scripts/import_sources.py`, les IDs composites et les propositions de liens. Augmenter la version et la date d’import quand les sources changent.
4. Lancer `python3 scripts/build.py`, puis `python3 tests/validate_data.py` et les tests navigateur décrits dans `tests/smoke.cjs`.
5. Faire valider les nouveaux liens et le périmètre par les responsables métier. Les sources non confirmées restent déclaratives.

Le futur module Outils est réservé ; aucune donnée de sa cartographie n’a été inventée. Pour l’intégrer, définir des IDs outils stables, une source et une date, des responsables et les relations documentées. Les anciennes mentions APPS restent séparées tant que la correspondance n’est pas établie.

## Hébergement privé

Déployer le contenu du ZIP sur un hébergement statique privé. L’authentification, les autorisations et le chiffrement TLS doivent être assurés par l’hébergeur ou un reverse proxy/SSO. Les données JSON, originaux et exports doivent bénéficier du même contrôle d’accès. Aucun mot de passe JavaScript, service de télémétrie ou envoi automatique n’est intégré. Le fichier autonome et le ZIP contiennent des informations internes et doivent rester sur les canaux internes autorisés.

## Usage en audit et contrôle

L’accueil privilégie l’espace **Audit & contrôle** et l’accès aux points P1. Ces priorités de revue sont celles du registre et ne constituent ni un score de risque, ni une évaluation de conformité. Le registre distingue l’information source, le suivi du point et la conclusion personnelle du test.

Pour chaque point, ouvrir **Feuille de travail — tests, preuves et actions**. Documenter l’objectif, le périmètre et la période, les travaux réalisés, les références des pièces examinées, les résultats, l’action, son responsable et son échéance, puis enregistrer. Les conclusions « écart constaté » et « aucun écart sur le périmètre testé » exigent un périmètre, des travaux, des références de preuves et une conclusion motivée. « Travaux à compléter » permet de conserver une préparation partielle. Cette saisie ne vérifie pas elle-même les pièces et ne constitue pas une revue contradictoire ou une validation du responsable d’audit.

Les feuilles de travail restent **locales au navigateur**. Aucun document de preuve n’est téléversé ou archivé : seules ses références sont saisies. L’export CSV comprend les données sources et les colonnes de travaux, preuves, conclusions et actions ; exporter avant de changer de poste, de navigateur, de fichier autonome ou d’effacer ses données locales. Le CSV ne peut pas être réimporté dans cette version. Les textes susceptibles d’être interprétés comme formules par un tableur sont préfixés d’une apostrophe à l’export.

Les constats partenaires ou produits disposant d’un chemin source précis proposent un accès à l’objet concerné. Aucune correspondance n’est créée sur une simple similarité de nom. L’outil aide à préparer et documenter une mission ; l’attribution des contrôles et les validations finales restent du ressort des responsables habilités. Les processus opérationnels, le contrôle permanent et l’audit interne demeurent distincts dans la cartographie.
