# Architecture fonctionnelle

```mermaid
flowchart TD
  Accueil[Portail ACHEEL] --> Recherche[Recherche globale et filtres]
  Accueil --> Fonctions[Chaînes → Fonctions → Processus]
  Accueil --> Produits[7 fiches produits → Acteurs et parcours]
  Accueil --> Partenaires[Familles → Partenaires → Offres / Conventions]
  Accueil --> Outils[Outils ACHEEL — à venir]
  Fonctions --> Ref[Référentiel commun versionné]
  Produits --> Ref
  Partenaires --> Ref
  Outils -. intégration future .-> Ref
  Ref --> Relations[Relations déclarées ou propositions à valider]
  Ref --> Registre[Registre de validation métier]
  Ref --> Export[Exports JSON / CSV / SVG]
  Sources[3 HTML originaux immuables] --> Import[Extraction JSON sans exécution]
  Import --> Ref
```

Application statique HTML/CSS/JavaScript sans serveur applicatif ni dépendance distante à l’exécution. `app.js` gère les routes par fragment, les vues communes, le panneau, les filtres et les interactions. `scripts/import_sources.py` extrait les blocs JSON sans exécuter les scripts joints, crée les identifiants et les relations avec source, chemin JSON et preuve. `scripts/build.py` génère les données JavaScript locales, une version autonome HTML et l’archive de déploiement.

Types distincts : entity, chain, function, process, product, offer, partner, convention (section d’analyse, pas PDF signé), tool, actor, participant (identité limitée au contexte partenaire), flow et journey. Identifiants préfixés par type ; codes et UID sources privilégiés, identifiants composites déterministes sinon. Un réordonnancement de sections sans clé source peut demander un contrôle des identifiants composites. Les versions et empreintes permettent de détecter ces changements.

Métadonnées communes : source, pointer, validation, referenceDate, owner, updatedAt. Une valeur inconnue reste nulle. Les relations ont leurs propres preuves et statuts. Aucun rapprochement produit/offre par ressemblance de nom. Le suivi local ne modifie pas les sources ni le statut documentaire des relations. À l’avenir, le module Outils devra importer ses propres objets et relations documentées, sans transformer les mentions APPS actuelles en données certifiées.

L’hébergement privé doit apporter l’authentification et l’autorisation côté serveur/SSO. Le portail n’ajoute aucun mot de passe JavaScript. Les originaux et les exports sont aussi confidentiels que les vues et doivent partager les mêmes règles d’accès.

## Travaux d’audit locaux

Les feuilles de travail sont conservées séparément du référentiel dans le navigateur (`acheel-workpapers-v1`). Leur clé est l’identifiant du point du registre. Le suivi local antérieur reste dans `acheel-validations-v1` et ne devient jamais une conclusion. Les champs exportables sont objectif, périmètre/période, test, références des preuves, résultats, action, responsable, échéance, conclusion et date de saisie. Aucun document n’est téléversé ni aucun résultat partagé automatiquement. Les filtres de priorité et de conclusion interrogent ces données sans modifier les sources.
