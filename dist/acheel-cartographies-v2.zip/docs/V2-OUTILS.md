# Intégration de la cartographie des outils — V2.1

## Source et inventaire

Le fichier `version finale - Cartographie des outils Acheel.html` est conservé à l’identique dans `sources/outils.html`. Son bloc JSON `const D` est décodé sans exécuter le JavaScript joint. L’empreinte SHA-256 et les chemins exacts sont dans `v2/data/outils.json`. La date de référence globale n’est pas établie par ce fichier ; les références au PSSI restent des déclarations de la source, sans vérification des documents originaux.

Les huit collections sont préservées : 46 outils, 52 sous-rubriques Omega, 7 écarts/questions, 36 flux, 31 nœuds de carte, 7 zones, 15 personnes et 28 entrées de glossaire. Les constantes explicatives sont également conservées en texte ; les descriptions des cinq interfaces sans fiche outil sont reprises par décodage de leurs chaînes, sans exécution.

## Ce qui devient accessible

L’entrée Outils ACHEEL est active, avec catalogue, recherche, périmètres, statuts, fiches complètes, flux et circuits, rubriques Omega, personnes, points d’attention, mentions historiques et glossaire. Les données complètes et l’original sont consultables. Les objets entrent aussi dans la recherche globale et le graphe des relations.

Les 36 flux conservent leurs origines, destinations, données, modes, fréquences, responsables et sources. Six portent le statut `tbc` et restent « À confirmer ». Les 30 autres portent le statut « ok » dans le fichier, mais cinq contiennent aussi une précision en attente dans leur détail. Ces cinq précisions sont signalées par un badge distinct et les relations correspondantes restent à confirmer dans le graphe. Aucun de ces libellés n’est présenté comme une vérification opérationnelle. Le filtre « déclarées seules » du graphe exclut les relations incertaines. Les nœuds sans fiche outil (SFTP, canaux, Excel, etc.) restent des interfaces/canaux ; ils n’augmentent pas artificiellement le nombre d’outils.

## Relations avec les processus et points de contrôle

52 citations nominales ont été repérées dans 21 fiches de processus. Cinq citations nomment un outil directement dans le texte d’un point de contrôle. Une citation documente une mention, mais ne prouve pas l’usage effectif ou la portée du contrôle : les correspondances sont donc à confirmer.

Les noms sont repris de la fiche outil ou de l’association explicite label/outil des nœuds de la source. BigQuery est une composante explicitement nommée dans « Data Warehouse (BigQuery) ». Les correspondances privilégient les noms complets : une mention de « Deemeter App » ne devient pas une mention de « Deemeter » par simple préfixe. Aucun rattachement à un processus précis n’est inventé à partir de libellés génériques tels que « Toutes les équipes ».

Le filtre **Outil cité dans le processus** des points de contrôle porte sur le contexte du processus. Il ne certifie pas que chaque point filtré concerne cet outil. La fiche du point distingue les citations directes du point et les mentions plus larges de la fiche processus. Les référents métier et technique d’un outil ne sont pas attribués automatiquement comme responsables de contrôle.

Les 491 points conservent leurs identifiants et leur source fonctionnelle. Les qualifications locales V2 et leurs exports restent compatibles. Les 7 écarts de la cartographie outils sont des points d’attention distincts, ajoutés au registre avec une priorité **Non cotée** ; ils ne sont pas transformés en résultats de contrôle ou en nouveaux contrôles avérés.

## Points de vigilance conservés

- Charlee, Hermes, Callity, Intercom, Customer.io et agents IA absents du PSSI d’après la source : à rapprocher de la version réelle du PSSI.
- Steex décrit comme historique mais toujours synchronisé vers le Data Warehouse : l’arrêt n’est pas déduit du statut historique.
- Regroupement Omega/Galileo et plan de migration à clarifier.
- Hermes annoncé remplacé, mais statut effectif et fermeture des accès encore interrogés dans les écarts : contradiction conservée.
- Nouveaux outils Data et accès Octopuce hors revue annuelle d’après le document.
- Circuits Omega, Deemeter et Charlee encore incertains.
- Création/suppression des accès décrite comme très centralisée ; l’organisation effective n’a pas été testée.

Les 11 mentions de l’ancienne source fonctionnelle restent consultables séparément. L’absence de Zendesk, Diabolocom, SYDIA/AIKAN ou de libellés composites dans la nouvelle liste ne prouve ni remplacement ni abandon. Aucun ancien objet n’est fusionné ou supprimé automatiquement.

## Maintenance et livraison

`python3 scripts/build_v2.py` extrait les outils, reconstruit la V2.1 et vérifie la préservation de la V1. Les sources spécifiques sont `scripts/build_tools.py`, `v2/tools-model.js` et `v2/tools-ui.js`. Le HTML autonome et le ZIP gardent leurs noms de livraison V2 pour actualiser les liens GitHub existants. La V1 et ses anciens fichiers livrés restent inchangés.

La quatrième cartographie est désormais disponible : les anciennes mentions « à venir » dans la documentation V1 décrivent son état antérieur. Aucun déploiement public n’est réalisé. Le contrôle d’accès du dépôt et de l’hébergement reste nécessaire pour ces données internes.

## Substitution par la version finale fournie

La version finale remplace la première pièce V3 comme source active. Celle-ci est archivée, sans modification, dans `archives/outils-version-intermediaire-V3.html` et dans le ZIP. Elle n’est pas comptée comme cinquième cartographie active.

Les changements métier sont repris comme déclarations de la version finale : premier paiement par carte via le formulaire et Stripe, mise en place du mandat GoCardless, échéances suivantes par prélèvement, confirmation Stripe et suivi GoCardless vers la base, et signature intégrée au parcours. Le flux `Callity → Excel` et le nœud Excel sont retirés de la carte active conformément à la source finale. Les mentions Callity de la source fonctionnelle restent séparées et à confirmer. Une constante explicative Excel inutilisée subsiste dans le code source fourni ; elle est conservée comme texte d’origine, sans générer un nœud ni un flux actif.

Les numéros de flux ont été renumérotés dans le document final. La plateforme utilise les identifiants et chemins de cette dernière version, sans assimiler deux flux par leur seul ancien numéro. Les identifiants des 491 points de contrôle fonctionnels et les qualifications associées sont inchangés.

### Statut du flux et précisions ouvertes

Le statut `ok` de la source ne suffit pas à lever une incertitude exprimée dans le détail. Les retours Stripe/GoCardless, le devenir des anciens contrats Hermes et les deux exports assistance comportent des précisions à confirmer. Le statut original est conservé, avec un badge complémentaire ; leurs relations sont exclues de la vue du graphe limitée aux relations déclarées sans réserve repérée.

## Résultats de validation

- 46 contrôles de données/outils réussis : égalité des collections aux données de la pièce finale, original et archive intermédiaire préservés, flux de paiement finaux, retrait Callity/Excel, statuts source et détails ouverts, citations exactes, absence de propriétaires de contrôle inventés et V1 inchangée.
- 49 contrôles navigateur outils réussis : 46 fiches outils, 36 flux, filtres de statut et de précision, 52 rubriques Omega, 15 personnes, 7 constats, 28 entrées de glossaire, recherche globale, registre, navigation entre contrôles et outils, toutes les 161 nouvelles fiches, graphes prudents, affichage mobile et HTML autonome hors ligne. Aucune erreur JavaScript ni ressource HTTP manquante observée.
- 46 contrôles de non-régression de la V2 réussis, notamment les 491 points, leurs qualifications, exports/imports, les 7 fiches produits et 105 offres partenaires.

Commandes : `python3 tests/validate_tools.py`, `python3 tests/validate_v2.py`, `node tests/tools_smoke.cjs` et `node tests/v2_smoke.cjs`. Les exemples de qualification n’existent que dans les contextes navigateur temporaires des tests. Aucune validation technique ne certifie l’effectivité des contrôles ni l’exactitude opérationnelle des déclarations métier.
